//3. Write a Program to find the area of Rectangle (Take Input from user)
#include<iostream>
using namespace std;

int main()
{
	int l,b;
	cout<<"Enter the length"<<endl;
	cin>>l;
	cout<<"Enter the breadth"<<endl;
	cin>>b;
	
	cout<<"Area of Rectangle:"<<l*b<<endl;
 	return 0;
}
