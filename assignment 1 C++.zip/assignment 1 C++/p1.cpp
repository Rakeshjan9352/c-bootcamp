//2. Learn about Mod(%) Operator
#include<iostream>
using namespace std;

int main()
{
	int l,b;
	cin>>l>>b;
	
	cout<<"Area of rectangle:"<<l*b;
	
	return 0;
}

