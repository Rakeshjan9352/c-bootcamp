//6. Write a Program to Print Your Family Members Name
#include<iostream>
using namespace std;

int main()
{
	char father[20],mother[20],sister[20],brother[20],name[20],grandfather[20],grandmother[20];
	
	cout<<"Enter First Name of ur GrandFather:";
	cin>>grandfather;
	cout<<"Enter First Name of ur GrandMother:";
	cin>>grandmother;
	cout<<"Enter First Name of ur Father:";
	cin>>father;
	//cout<<"Enter First Name of ur Brother:";
	//cin>>brother;
	cout<<"Enter First Name of ur Mother:";
	cin>>mother;
	cout<<"Enter First Name of ur Sister:";
	cin>>sister;
	cout<<"Enter First Name of ur Brother:";
	cin>>brother;
	cout<<"\n Enter Your First Name:";
	cin>>name;
	cout<<"### your family ####";
	
	cout<<"\nGrandParents \t-->"<<grandfather<<" + "<<grandmother;
	cout<<"\nParents \t-->"<<father<<" + "<<mother;
	cout<<"\nSibling \t-->"<<sister<<" + "<<brother;
	cout<<"\nMe \t\t-->"<<name;
	return 0;
}

