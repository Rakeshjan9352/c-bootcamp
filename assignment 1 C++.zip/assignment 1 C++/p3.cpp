//5. Write a Program to convert temperature in Celsius to Fahrenheit 
#include<iostream>
using namespace std;

int main()
{
	float cel,far;
	cout<"Temperature in celsius:";
	cin>>cel;
	
	far=(cel*9/5)+32;
	
	cout<<"Temperature in fahrenheit:"<<far;
	
	return 0;
}

