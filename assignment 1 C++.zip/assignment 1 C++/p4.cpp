// 7. Write a Program to add, subtract, multiply and divide two numbers (Take Input from user)
#include<iostream>
using namespace std;

int main()
{
	int a,b,sum,sub,div,mul;
	cin>>a>>b;
	
	sum=a+b;
	sub=a-b;
	div=a*b;
	mul=a/b;
	
	cout<<"Two number is add:"<<sum<<sub<<div<<mul;
	return 0;
}

