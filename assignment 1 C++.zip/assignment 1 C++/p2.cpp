//4. Write a Program to find area of Circle (Without taking user input)
#include<iostream>
using namespace std;

int main()
{
	float r;
	cin>>r;
	
	cout<<"Area of circle:"<<3.14*r*r;
	
	return 0;
}

