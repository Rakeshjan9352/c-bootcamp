#include<iostream>
using namespace std;

int main()
{
	int i,j;
	
	for(i=1; i<=7; i++)
	{
		for(j=6; j>=i; j--)
		{
			cout<<" ";
		}
		for(int k=1; k<=i; k++)
		{
			cout<<"*"<<" ";
		}
		cout<<endl;
	}
 	return 0;
}
