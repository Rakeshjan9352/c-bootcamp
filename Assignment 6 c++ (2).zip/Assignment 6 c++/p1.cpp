#include<iostream>
using namespace std;

int main()
{
	int i,j;
	
	for(i=1; i<=5; i++)
	{
		for(j=1; j<=3; j++)
		{
			cout<<"*"<<" ";
		}
		cout<<"\n";
	}
 	return 0;
}
